$(document).ready(function(){
	AOS.init({ disable: 'mobile' });
});